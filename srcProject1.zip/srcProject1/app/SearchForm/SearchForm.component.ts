import { Component, OnInit } from '@angular/core';
import {ProductList} from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-home',
  templateUrl: './SearchForm.component.html',
  styleUrls: ['./SearchForm.component.css']
})
export class SearchFormComponent implements OnInit {
  proList: ProductList[] ;
indicator: boolean;
  empl: ProductList[];
  constructor(private search: EmployeeService) { }

  ngOnInit() {
    this.getAll();
  }
  getAll() {
    this.search.getAll().subscribe(data => this.proList = data);
    }

  searching(data) {
      let j = 0;
      this.empl= [];
      this.indicator=true;
      for (let i = 0; i < this.proList.length; i++) {
      if (data.value.name === this.proList[i].name || data.value.name === this.proList[i].category) {
      this.empl[j] = this.proList[i];
      j++;
      }
      else {
        this.indicator=true;
      
      
      }
      }
      }
}
