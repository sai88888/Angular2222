



export interface ProductList {

id: string;
name: string;
price: number;
category: string;

   }
