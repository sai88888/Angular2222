import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
uname: string;
  constructor(private route: ActivatedRoute) {
route.params.subscribe(params => this.uname = params['uname'])
}
  ngOnInit() {
  }

}
