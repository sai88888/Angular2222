import { Component, OnInit , Output, EventEmitter } from '@angular/core';
import { EmployeeService } from '../employee.service';
import {Employee} from '../employee';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})

  export class SearchEmployeeComponent implements OnInit {

    add: EmployeeService = new EmployeeService();
    empList: Employee[];

    constructor() { }

    ngOnInit() {
    }


    addemp(empform) {
      this.add.addEmpService(empform);
    }

  }

