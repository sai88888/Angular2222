import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

id: number;
name: string;
sal: number;
dep: string;
thor: Object;
formdata(myform) {

  alert(myform.value.id + myform.value.name + myform.value.sal + myform.value.dep);
this.id = myform.value.id;
this.name = myform.value.name;
this.sal = myform.value.sal;
this.dep = myform.value.dep;
}

}
