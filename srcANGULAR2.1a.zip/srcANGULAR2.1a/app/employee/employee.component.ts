import { Component, OnInit } from '@angular/core';

import {EmployeeService} from '../employee.service';
import {Employee} from '../employee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
    uId: number;
    uName: string;
    uSal: number;
    uDep: string;


  empList: Employee[] = [];
  constructor(private service: EmployeeService) { }

  ngOnInit() {
    this.getAllEmployee();
  }
getAllEmployee() {
  this.service.getAllEmployees().subscribe(data => this.empList = data);
}
addEmployee(myform) {
this.empList.push(myform.value);
}
updateEmp(dataupdate) {
  this.uId = dataupdate.empId;
  this.uName = dataupdate.empName;
  this.uSal = dataupdate.empSal;
  this.uDep = dataupdate.empDep;

}
updateEmployee(updateform) {
  for (let i = 0; i < this.empList.length; i++) {
  if (this.empList[i].empId === updateform.uId) {
  this.empList[i].empName = updateform.uName;
  this.empList[i].empSal = updateform.uSal;
  this.empList[i].empDep = updateform.uDep;

  }
  }
}



deleteEmployee(i) {
  this.empList.splice( i , 1);
  }
}








