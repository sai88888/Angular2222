import { Injectable } from '@angular/core';
import { Employee } from './Employee';

@Injectable({
providedIn: 'root'
})
export class EmployeeService {


static employeeArray: Employee[] = [];

constructor() { }

addEmployeeService(addForm) {
let  employeeObj = new Employee();
employeeObj.id = addForm.id;
employeeObj.name = addForm.name;
employeeObj.email = addForm.email;
employeeObj.phone = addForm.phone;
EmployeeService.employeeArray.push(employeeObj);
return EmployeeService.employeeArray;
 }

listEmployeeService() {
return EmployeeService.employeeArray;
 }

deleteEmployeeService(i) {
EmployeeService.employeeArray.splice(i, 1);
 }

empUpdateService(val) {
for (let i = 0; i < EmployeeService.employeeArray.length; i++) {
if (val.id === EmployeeService.employeeArray[i].id) {
EmployeeService.employeeArray[i] = val;
 }
 }
return EmployeeService.employeeArray;
 }

}

