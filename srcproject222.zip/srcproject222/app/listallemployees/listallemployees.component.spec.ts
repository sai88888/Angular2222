import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListallEmployeesComponent } from './listallemployees.component';

describe('ListallemployeesComponent', () => {
  let component: ListallEmployeesComponent;
  let fixture: ComponentFixture<ListallEmployeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListallEmployeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListallEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
