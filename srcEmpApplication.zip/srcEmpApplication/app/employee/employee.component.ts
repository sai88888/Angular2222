import { Component, OnInit } from '@angular/core';

import { EmployeeService } from '../employee.service';
import {Employee} from '../employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
empList: Employee [];
empl: Employee;
  constructor(private service: EmployeeService) { }

  ngOnInit() {
    this.getAllEmployee();
  }
getAllEmployee() {
this.service.getAllEmployees().subscribe(data => this.empList = data);
}
deleteEmployee(i) {
this.empList.splice( i , 1);
}
delete(myform) {
alert(myform.value.eid);
for (let i = 0; i < this.empList.length; i++) {
if (this.empList[i].eid === myform.value.eid) {
  this.empList.splice(i, 1);
}
}
}
getEmployee(getform) {

  for (let i = 0; i < this.empList.length; i++) {
  if (this.empList[i].eid === getform.value.eid) {
     this.empl = this.empList[i];
  }
  }
  }
addEmployee(addform) {
this.empList.push(addform.value);
}
updateEmployee(updateform) {
for (let i = 0; i < this.empList.length; i++) {
if (this.empList[i].eid === updateform.value.eid) {
this.empList[i] = updateform.value;
}
  }
}
}
